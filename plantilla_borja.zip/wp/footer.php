<footer class="main-footer">
		<div class="container">
			<div class="f_left">
				<p>&copy; 2019 - Hedgehog Fingerboards</p>
			</div>
			<div class="f_right">
				<ul>
					<li><a href="http://www.twitter.com"><img src="http://localhost/wordpress/wp-content/uploads/2019/02/twitter-round-logo-png-transparent-background-7.png" alt="" width="50px" height="50px"></a></li>


					<li><a href="http://www.facebook.com"><img src="http://localhost/wordpress/wp-content/uploads/2019/02/facebook-logo-png-9.png" alt="" width="50px" height="50px"></a></li>
					

					<li><a href="http://www.instagram.com"><img src="http://localhost/wordpress/wp-content/uploads/2019/02/ig-logo-email.png" alt="" width="50px" height="50px"></a></li>
				</ul>
			</div>

		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>


